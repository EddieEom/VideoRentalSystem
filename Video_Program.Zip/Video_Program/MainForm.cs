namespace Video_Program
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }


        // 자식폼 중복 생성 방지 메서드
        private void OpenChild(Form childForm)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (frm.GetType() == childForm.GetType())
                {
                    frm.Activate();
                    return;
                }
            }

            childForm.MdiParent = this;
            childForm.Show();
        }

        // MenuStrip 파일 - 모두 열기
        private void Tool_AllOpen_Click(object sender, EventArgs e)
        {
            OpenChild(new Video_Info());

            OpenChild(new Rental_management());

            OpenChild(new User_Info());

            OpenChild(new Information_Select());

            OpenChild(new Video_Rental_Setting());

            OpenChild(new Video_Excel_Setting());
        }

        // 메뉴 - 닫기 기능
        private void Tool_Close_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
            {
                this.ActiveMdiChild.Close();
            }
        }

        // 메뉴 - 모두 닫기 기능
        private void Tool_AllClose_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                frm.Close();
            }
        }


        // 메뉴 - 환경설정 기능
        private void Tool_Setting_Click(object sender, EventArgs e)
        {
            OpenChild(new Video_Rental_Setting());
            OpenChild(new Video_Excel_Setting());
        }

        // 메뉴 - 대여 관리 기능
        private void Tool_RentalManage_Click(object sender, EventArgs e)
        {
            OpenChild(new Rental_management());
        }


        private void Tool_leaseNreturn_Click(object sender, EventArgs e)
        {
            Tool_RentalManage_Click(sender, e);
        }

        // 메뉴 - 대여 반납 기능
        private void Tool_VideoInfo_Click(object sender, EventArgs e)
        {
            Rental_management rental_Management = new Rental_management();
            rental_Management.MdiParent = this;
            rental_Management.Show();
        }

        private void Tool_Video_Click(object sender, EventArgs e)
        {
            OpenChild(new Video_Info());
        }

        private void Tool_Customer_Click(object sender, EventArgs e)
        {
            User_Info user_Info = new User_Info();
            user_Info.MdiParent = this;
            user_Info.Show();
        }

        private void Tool_User_Click(object sender, EventArgs e)
        {
            OpenChild(new User_Info());

        }

        private void Tool_VideoSelect_Click(object sender, EventArgs e)
        {
            Information_Select information_Select = new Information_Select();
            information_Select.MdiParent = this;
            information_Select.Show();
        }

        private void Tool_Info_Click(object sender, EventArgs e)
        {
            OpenChild(new Information_Select());
        }

        private void Tool_VideoRentalSetting_Click(object sender, EventArgs e)
        {
            Video_Rental_Setting video_Rental_Setting = new Video_Rental_Setting();
            video_Rental_Setting.MdiParent = this;
            video_Rental_Setting.Show();
        }

        private void Tm_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Tm_Excel_Info_Click(object sender, EventArgs e)
        {
            Video_Excel_Setting video_Excel_Setting = new Video_Excel_Setting();
            video_Excel_Setting.MdiParent = this;
            video_Excel_Setting.Show();
        }
    }
}
