﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ClosedXML.Excel;

namespace Video_Program
{
    public partial class Video_Excel_Setting : Form
    {

        // 닫기 및 모두 닫기 시 수정여부
        public bool IsModified = false;

        // DB 연결
        private string connStr = @"Server=localhost;Database=VideoRentalDB;Trusted_Connection=True;TrustServerCertificate=True";

        private SqlConnection conn;

        public Video_Excel_Setting()
        {
            InitializeComponent();
        }


        private void Video_Excel_Setting_Load(object sender, EventArgs e)
        {
            LoadGenre();
        }

        private void LoadGenre()
        {
            try
            {
                Cb_VideoGenre.Items.Clear();

                Cb_VideoGenre.Items.Add("전체");

                conn =
                new SqlConnection(connStr);

                conn.Open();

                SqlCommand cmd =
                new SqlCommand(

                "SELECT DISTINCT Genre FROM VIDEO"

                , conn);

                SqlDataReader dr =
                cmd.ExecuteReader();

                while (dr.Read())
                {
                    Cb_VideoGenre.Items.Add(

                    dr["Genre"]
                    .ToString() ?? ""

                    );
                }

                dr.Close();

                conn.Close();

                Cb_VideoGenre.SelectedIndex = 0;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SaveExcel(
    SqlDataReader dr,
    string fileName)
        {
            SaveFileDialog save =
                new SaveFileDialog();

            save.Filter =
                "Excel 파일 (*.xlsx)|*.xlsx";

            save.FileName =
                fileName;

            if (save.ShowDialog()
                != DialogResult.OK)
            {
                return;
            }

            using (var workbook =
                new XLWorkbook())
            {
                var worksheet =
                    workbook.Worksheets.Add(
                    "목록");

                // 헤더

                for (int i = 0;
                     i < dr.FieldCount;
                     i++)
                {
                    worksheet.Cell(
                        1,
                        i + 1)

                        .Value =

                        dr.GetName(i);
                }

                // 데이터

                int row = 2;

                while (dr.Read())
                {
                    for (int col = 0;
                         col < dr.FieldCount;
                         col++)
                    {
                        worksheet.Cell(
                            row,
                            col + 1)

                            .Value =

                            dr[col]
                            .ToString();
                    }

                    row++;
                }

                worksheet.Columns()
                .AdjustToContents();

                workbook.SaveAs(
                    save.FileName);
            }
        }

        private void Btn_VideoList_Click(object sender, EventArgs e)
        {
            try
            {
                conn =
                new SqlConnection(connStr);

                conn.Open();

                string sql;

                if (Cb_VideoGenre.Text
                == "전체")
                {
                    sql =

                    @"SELECT *

            FROM VIDEO

            ORDER BY VideoCode";
                }

                else
                {
                    sql =

                    @"SELECT *

            FROM VIDEO

            WHERE Genre=@Genre

            ORDER BY VideoCode";
                }

                SqlCommand cmd =
                new SqlCommand(
                sql,
                conn);

                if (Cb_VideoGenre.Text
                != "전체")
                {
                    cmd.Parameters.AddWithValue(
                    "@Genre",

                    Cb_VideoGenre.Text);
                }

                SqlDataReader dr =
                cmd.ExecuteReader();

                SaveExcel(
                dr,

                "비디오목록.xlsx");

                dr.Close();

                conn.Close();

                MessageBox.Show(
                "저장 완료");
            }

            catch (Exception ex)
            {
                MessageBox.Show(
                ex.Message);
            }
        }

        private void Btn_RentalStatus_Click(object sender, EventArgs e)
        {
            try
            {
                conn =
                new SqlConnection(connStr);

                conn.Open();

                SqlCommand cmd =
                new SqlCommand(

                @"SELECT *

        FROM RENTAL

        ORDER BY RentalNo"

                , conn);

                SqlDataReader dr =
                cmd.ExecuteReader();

                SaveExcel(
                dr,

                "대여현황.xlsx");

                dr.Close();

                conn.Close();

                MessageBox.Show(
                "저장 완료");
            }

            catch (Exception ex)
            {
                MessageBox.Show(
                ex.Message);
            }
        }
    }
}
