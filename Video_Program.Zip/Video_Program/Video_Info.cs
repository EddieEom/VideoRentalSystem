﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Video_Program
{
    public partial class Video_Info : Form
    {

        private string connStr =
        @"Server=localhost;
        Database=VideoRentalDB;
        Trusted_Connection=True;
        TrustServerCertificate=True";

        private SqlConnection conn;

        // 수정 여부
        public bool IsModified = false;

        public Video_Info()
        {
            InitializeComponent();
        }

        private void LoadVideoCount()
        {
            try
            {
                conn = new SqlConnection(connStr);

                conn.Open();

                SqlCommand cmd =
                    new SqlCommand(
                    "SELECT COUNT(*) FROM VIDEO",
                    conn);

                int count =
                    (int)cmd.ExecuteScalar();

                Video_Count.Text =
                    count + "개";

                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadVideo()
        {
            try
            {
                GV_Video.Rows.Clear();

                conn =
                    new SqlConnection(connStr);

                conn.Open();

                SqlCommand cmd =
                    new SqlCommand(
                    "Select_All_Video",
                    conn);

                cmd.CommandType =
                    CommandType.StoredProcedure;

                SqlDataReader dr =
                    cmd.ExecuteReader();

                while (dr.Read())
                {
                    GV_Video.Rows.Add(

                        dr["VideoCode"],

                        dr["Genre"],

                        dr["Title"],

                        dr["MainActor"],

                        dr["Director"],

                        dr["Distributor"],

                        dr["ReleaseDate"]
                    );
                }

                dr.Close();

                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Video_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                conn =
                    new SqlConnection(connStr);

                conn.Open();

                SqlCommand cmd =
                    new SqlCommand(
                    "Insert_Video",
                    conn);

                cmd.CommandType =
                    CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue(
                    "@VideoCode",
                    Convert.ToInt32(
                    Tb_VideoCode.Text));

                cmd.Parameters.AddWithValue(
                    "@Title",
                    Tb_Title.Text);

                cmd.Parameters.AddWithValue(
                    "@Genre",
                    Tb_Genre.Text);

                cmd.Parameters.AddWithValue(
                    "@MainActor",
                    Tb_MainActor.Text);

                cmd.Parameters.AddWithValue(
                    "@Director",
                    Tb_Director.Text);

                cmd.Parameters.AddWithValue(
                    "@Distributor",
                    Tb_Distributor.Text);

                cmd.Parameters.AddWithValue(
                    "@ReleaseDate",
                    Dt_Video_Info.Value);

                cmd.ExecuteNonQuery();

                MessageBox.Show("추가 완료");

                LoadVideo();

                LoadVideoCount();

                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Video_Save_Click(object sender, EventArgs e)
        {
            try
            {
                conn =
                    new SqlConnection(connStr);

                conn.Open();

                SqlCommand cmd =
                    new SqlCommand(
                    "Update_Video",
                    conn);

                cmd.CommandType =
                    CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue(
                    "@VideoCode",
                    Convert.ToInt32(
                    Tb_VideoCode.Text));

                cmd.Parameters.AddWithValue(
                    "@Title",
                    Tb_Title.Text);

                cmd.Parameters.AddWithValue(
                    "@Genre",
                    Tb_Genre.Text);

                cmd.Parameters.AddWithValue(
                    "@MainActor",
                    Tb_MainActor.Text);

                cmd.Parameters.AddWithValue(
                    "@Director",
                    Tb_Director.Text);

                cmd.Parameters.AddWithValue(
                    "@Distributor",
                    Tb_Distributor.Text);

                cmd.Parameters.AddWithValue(
                    "@ReleaseDate",
                    Dt_Video_Info.Value);

                cmd.ExecuteNonQuery();

                MessageBox.Show("저장 완료");

                LoadVideo();

                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Video_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                conn =
                    new SqlConnection(connStr);

                conn.Open();

                SqlCommand cmd =
                    new SqlCommand(
                    "Delete_Video",
                    conn);

                cmd.CommandType =
                    CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue(
                    "@VideoCode",
                    Convert.ToInt32(
                    Tb_VideoCode.Text));

                cmd.ExecuteNonQuery();

                MessageBox.Show("삭제 완료");

                LoadVideo();

                LoadVideoCount();

                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GV_Video_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            Tb_VideoCode.Text =
                GV_Video.Rows[e.RowIndex]
                .Cells[0]
                .Value?.ToString();

            Tb_Genre.Text =
                GV_Video.Rows[e.RowIndex]
                .Cells[1]
                .Value?.ToString();

            Tb_Title.Text =
                GV_Video.Rows[e.RowIndex]
                .Cells[2]
                .Value?.ToString();

            Tb_MainActor.Text =
                GV_Video.Rows[e.RowIndex]
                .Cells[3]
                .Value?.ToString();

            Tb_Director.Text =
                GV_Video.Rows[e.RowIndex]
                .Cells[4]
                .Value?.ToString();

            Tb_Distributor.Text =
                GV_Video.Rows[e.RowIndex]
                .Cells[5]
                .Value?.ToString();

            Dt_Video_Info.Value =
                Convert.ToDateTime(

                GV_Video.Rows[e.RowIndex]
                .Cells[6]
                .Value
                );
        }

        private void Video_Info_Load(object sender, EventArgs e)
        {
            LoadVideo();

            LoadVideoCount();
        }

        private void Btn_VideoList_Save_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog save =
                    new SaveFileDialog();

                save.Filter =
                    "CSV 파일 (*.csv)|*.csv";

                save.FileName =
                    "비디오목록.csv";

                if (save.ShowDialog()
                    != DialogResult.OK)
                {
                    return;
                }

                StreamWriter sw =
                    new StreamWriter(
                    save.FileName,
                    false,
                    Encoding.UTF8);

                // 헤더 저장

                for (int i = 0;
                    i < GV_Video.Columns.Count;
                    i++)
                {
                    sw.Write(
                    GV_Video.Columns[i]
                    .HeaderText);

                    if (i <
                    GV_Video.Columns.Count - 1)

                        sw.Write(",");
                }

                sw.WriteLine();

                // 데이터 저장

                foreach (DataGridViewRow row
                    in GV_Video.Rows)
                {
                    if (row.IsNewRow)
                        continue;

                    for (int i = 0;
                        i < GV_Video.Columns.Count;
                        i++)
                    {
                        sw.Write(
                        row.Cells[i]
                        .Value);

                        if (i <
                        GV_Video.Columns.Count - 1)

                            sw.Write(",");
                    }

                    sw.WriteLine();
                }

                sw.Close();

                MessageBox.Show(
                "목록 저장 완료");
            }

            catch (Exception ex)
            {
                MessageBox.Show(
                ex.Message);
            }
        }

        private void Btn_Video_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
