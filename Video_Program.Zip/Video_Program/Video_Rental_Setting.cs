﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Video_Program
{
    public partial class Video_Rental_Setting : Form
    {

        // 닫기 및 모두 닫기 시 수정여부
        public bool IsModified = false;

        // DB 연결
        private string connStr = @"Server=localhost;Database=VideoRentalDB;Trusted_Connection=True;TrustServerCertificate=True";

        private SqlConnection conn;
        public Video_Rental_Setting()
        {
            InitializeComponent();
        }

        private void LoadConfig()
        {
            try
            {
                conn = new SqlConnection(connStr);

                conn.Open();

                SqlCommand cmd =
                    new SqlCommand(
                    "Select_Config",
                    conn);

                cmd.CommandType =
                    CommandType.StoredProcedure;

                SqlDataReader dr =
                    cmd.ExecuteReader();

                while (dr.Read())
                {
                    string type =
                        dr["ProgramType"].ToString() ?? "";

                    if (type == "신작")
                    {
                        Tb_New_ChangeTime.Text =
                            dr["ChangeDays"]
                            .ToString();

                        Tb_New_RentalDays.Text =
                            dr["RentalDays"]
                            .ToString();

                        Tb_New_RentalFee.Text =
                            dr["RentalFee"]
                            .ToString();

                        Tb_New_LateFee.Text =
                            dr["LateFee"]
                            .ToString();
                    }

                    else if (type == "구작")
                    {
                        Tb_Old_RentalDays.Text =
                            dr["RentalDays"]
                            .ToString();

                        Tb_Old_RentalFee.Text =
                            dr["RentalFee"]
                            .ToString();

                        Tb_Old_LateFee.Text =
                            dr["LateFee"]
                            .ToString();
                    }
                }

                dr.Close();

                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Video_Rental_Setting_Load(object sender, EventArgs e)
        {
            LoadConfig();
        }


        private void InsertConfig(
        int id,
        string type,
        string? changeDay,
        string day,
        string fee,
        string late)

        {
            SqlCommand cmd =
            new SqlCommand(
            "Insert_Config",
            conn);

            cmd.CommandType =
            CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue(
            "@ConfigID",
            id);

            cmd.Parameters.AddWithValue(
            "@ProgramType",
            type);

            // 전환기간
            if (string.IsNullOrWhiteSpace(changeDay))
            {
                cmd.Parameters.AddWithValue(
                "@ChangeDays",
                DBNull.Value);
            }

            else
            {
                cmd.Parameters.AddWithValue(
                "@ChangeDays",
                Convert.ToInt32(changeDay));
            }

            cmd.Parameters.AddWithValue(
            "@RentalDays",
            Convert.ToInt32(day));

            cmd.Parameters.AddWithValue(
            "@RentalFee",
            Convert.ToInt32(fee));

            cmd.Parameters.AddWithValue(
            "@LateFee",
            Convert.ToInt32(late));

            cmd.ExecuteNonQuery();
        }


        private void Btn_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                conn =
                new SqlConnection(connStr);

                conn.Open();

                InsertConfig(
                    1,
                    "신작",

                    Tb_New_ChangeTime.Text,

                    Tb_New_RentalDays.Text,

                    Tb_New_RentalFee.Text,

                    Tb_New_LateFee.Text
                );

                InsertConfig(
                    2,
                    "구작",

                    null,

                    Tb_Old_RentalDays.Text,

                    Tb_Old_RentalFee.Text,

                    Tb_Old_LateFee.Text
                );

                MessageBox.Show(
                "등록 완료");
                LoadConfig();
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateConfig(
        int id,
        string type,
        string? changeDay,
        string day,
        string fee,
        string late)
        {
            SqlCommand cmd =
            new SqlCommand(
            "Update_Config",
            conn);

            cmd.CommandType =
            CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue(
            "@ConfigID",
            id);

            cmd.Parameters.AddWithValue(
            "@ProgramType",
            type);

            // 전환기간
            if (string.IsNullOrWhiteSpace(changeDay))
            {
                cmd.Parameters.AddWithValue(
                "@ChangeDays",
                DBNull.Value);
            }

            else
            {
                cmd.Parameters.AddWithValue(
                "@ChangeDays",
                Convert.ToInt32(changeDay));
            }

            cmd.Parameters.AddWithValue(
            "@RentalDays",
            Convert.ToInt32(day));

            cmd.Parameters.AddWithValue(
            "@RentalFee",
            Convert.ToInt32(fee));

            cmd.Parameters.AddWithValue(
            "@LateFee",
            Convert.ToInt32(late));

            cmd.ExecuteNonQuery();
        }

        private void Btn_Update_Click(object sender, EventArgs e)
        {
            try
            {
                conn =
                new SqlConnection(connStr);

                conn.Open();

                UpdateConfig(
                    1,
                    "신작",
                    Tb_New_ChangeTime.Text,
                    Tb_New_RentalDays.Text,
                    Tb_New_RentalFee.Text,
                    Tb_New_LateFee.Text
                );

                UpdateConfig(
                    2,
                    "구작",
                    null,
                    Tb_Old_RentalDays.Text,
                    Tb_Old_RentalFee.Text,
                    Tb_Old_LateFee.Text
                );

                MessageBox.Show(
                "수정 완료");
                LoadConfig();
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
